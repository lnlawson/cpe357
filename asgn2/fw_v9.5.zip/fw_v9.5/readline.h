#ifndef READLINEH
#define READLINEH
#include <stdio.h>
extern char *readline(FILE *);
#endif